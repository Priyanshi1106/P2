//
// raft.go
// =======
// Write your code in this file
// We will use the original version of all other
// files for testing
//

package raft

//
// API
// ===
// This is an outline of the API that your raft implementation should
// expose.
//
// rf = Make(...)
//   Create a new Raft peer.
//
// rf.Start(command interface{}) (index, term, isleader)
//   Start agreement on a new log entry
//
// rf.GetState() (me, term, isLeader)
//   Ask a Raft peer for "me" (see line 58), its current term, and whether it thinks it
//   is a leader
//
// ApplyMsg
//   Each time a new entry is committed to the log, each Raft peer
//   should send an ApplyMsg to the service (e.g. tester) on the
//   same peer, via the applyCh channel passed to Make()
//

import "sync"
import "github.com/cmu440/rpc"
import "math/rand"
import "container/list"
import "time"
//import "fmt"

//
// ApplyMsg
// ========
//
// As each Raft peer becomes aware that successive log entries are
// committed, the peer should send an ApplyMsg to the service (or
// tester) on the same peer, via the applyCh passed to Make()
//
type ApplyMsg struct {
	Term int
	Index   int
	Command interface{}
}

//
// Raft struct
// ===========
//
// A Go object implementing a single Raft peer
//
type Raft struct {
	mux   sync.Mutex       // Lock to protect shared access to this peer's state
	peers []*rpc.ClientEnd // RPC end points of all peers
	me    int              // this peer's index into peers[]
	timeout int
	// Your data here (2A, 2B).
	// Look at the Raft paper's Figure 2 for a description of what
	// state a Raft peer should maintain
	currentTerm int
	votedFor int
	log *list.List	// Should I make another struct?
	lastTerm int
	lastIndex int
	voteCount int

	commitIndex	int
	lastApplied int

	isLeader bool
	nextIndex	[]int
	matchIndex []int
	leaderElected chan bool
	receivedMsg chan bool
	receivedVoteReply chan RequestVoteReply
	receivedAppendReply chan AppendEntriesReply

	killTimeout chan bool
}

//
// GetState()
// ==========
//
// Return "me", current term and whether this peer
// believes it is the leader
//
func (rf *Raft) GetState() (int, int, bool) {

	rf.mux.Lock()
	me := rf.me
	term := rf.currentTerm
	isLeader := rf.isLeader
	rf.mux.Unlock()
	return me, term, isLeader
}

//
// RequestVoteArgs
// ===============
//
// Example RequestVote RPC arguments structure
//
// Please note
// ===========
// Field names must start with capital letters!
//
type RequestVoteArgs struct {
	// Your data here (2A, 2B)
	Term int
	CandidateId int
	LastLogIndex	 int
	LastLogTerm	 int
}

//
// RequestVoteReply
// ================
//
// Example RequestVote RPC reply structure.
//
// Please note
// ===========
// Field names must start with capital letters!
//
//
type RequestVoteReply struct {
	// Your data here (2A)
	Term int
	VoteGranted bool
}

type AppendEntriesArgs struct {
	Term int
	LeaderId int
	PrevLogIndex int
	PrevLogTerm int

	LeaderCommit int
}

type AppendEntriesReply struct {
	Term int
	Success bool
}

//
// RequestVote
// ===========
//
// Example RequestVote RPC handler
//
func (rf *Raft) RequestVote(args *RequestVoteArgs, reply *RequestVoteReply) {
	// Your code here (2A, 2B)
	// If requestVote comes, check:

	rf.receivedMsg <- true
	rf.mux.Lock()
	if rf.currentTerm > args.Term {
		//fmt.Println("Case 1")
		reply.VoteGranted = false
		reply.Term = rf.currentTerm
		rf.mux.Unlock()
		return
	} else if rf.currentTerm == args.Term && (rf.votedFor == -1 || rf.votedFor == args.CandidateId) {
			// TODO: Do this
			if rf.lastTerm <= args.LastLogTerm && rf.lastIndex <= args.LastLogIndex {
				rf.isLeader = false
				reply.VoteGranted = true
				reply.Term = rf.currentTerm
				rf.votedFor = args.CandidateId
				//fmt.Println("Case 2")
				rf.mux.Unlock()
				return
			} else {
				reply.VoteGranted = false
				reply.Term = rf.currentTerm
				//fmt.Println("Case 3")
				rf.mux.Unlock()
				return
			}

	} else if rf.currentTerm < args.Term && rf.lastTerm <= args.LastLogTerm && rf.lastIndex <= args.LastLogIndex {
		rf.isLeader = false
		rf.currentTerm = args.Term
		reply.VoteGranted = true
		reply.Term = rf.currentTerm
		rf.votedFor = args.CandidateId
		//fmt.Println("Case 2")
		rf.mux.Unlock()
		return
	}
}

func (rf *Raft) AppendEntries(args *AppendEntriesArgs, reply *AppendEntriesReply) {
	rf.mux.Lock()
	//fmt.Printf("Term received %d and current term %d\n", args.Term, rf.currentTerm)
	if args.Term < rf.currentTerm {
		//fmt.Printf("Server %d got stale message of term %d \n", rf.me, args.Term)
		reply.Term = rf.currentTerm
		reply.Success = false
		rf.mux.Unlock()
		return
	} else {
		// What if the entries are nil?
		//var value ApplyMsg{}
		matched := false
		if rf.log.Len() != 0{
			//fmt.Println("Shoudl not happen!!!")
			for ele := rf.log.Front(); ele != nil; ele = ele.Next() {
				value := ele.Value.(ApplyMsg)
				if value.Index == args.PrevLogIndex {
					if value.Term != args.PrevLogTerm {
						reply.Term = rf.currentTerm
						reply.Success = false
						matched = true
					} else {
						reply.Term = rf.currentTerm
						reply.Success = true
						matched = false
						rf.mux.Unlock()
						rf.receivedMsg <- true
						return
					}
					if (matched) {
						elePrev := ele.Prev()
						rf.log.Remove(ele)
						ele = elePrev
					}
				}
			}
			rf.mux.Unlock()
			return
		} else {
			if args.PrevLogIndex == 0 && args.PrevLogTerm == 0 {
				//fmt.Printf("Server %d: Updated term %d to %d\n", rf.me, rf.currentTerm, args.Term)
				rf.currentTerm = args.Term
				reply.Term = rf.currentTerm
				reply.Success = true
				rf.mux.Unlock()
				rf.receivedMsg <- true
				return
			}
		}
		// TODO: append new entries to the log
		// TODO: something about leaderCommit
	}
}

//
// sendRequestVote
// ===============
//
// Example code to send a RequestVote RPC to a peer
//
// peer int -- index of the target peer in
// rf.peers[]
//
// args *RequestVoteArgs -- RPC arguments in args
//
// reply *RequestVoteReply -- RPC reply
//
// The types of args and reply passed to Call() must be
// the same as the types of the arguments declared in the
// handler function (including whether they are pointers)
//
// The rpc package simulates a lossy network, in which peers
// may be unreachable, and in which requests and replies may be lost
//
// Call() sends a request and waits for a reply
//
// If a reply arrives within a timeout interval, Call() returns true;
// otherwise Call() returns false
//
// Thus Call() may not return for a while
//
// A false return can be caused by a dead peer, a live peer that
// can't be reached, a lost request, or a lost reply
//
// Call() is guaranteed to return (perhaps after a delay)
// *except* if the handler function on the peer side does not return
//
// Thus there
// is no need to implement your own timeouts around Call()
//
// Please look at the comments and documentation in ../rpc/rpc.go
// for more details
//
// If you are having trouble getting RPC to work, check that you have
// capitalized all field names in the struct passed over RPC, and
// that the caller passes the address of the reply struct with "&",
// not the struct itself
//
func (rf *Raft) sendRequestVote(peer int, args *RequestVoteArgs, reply *RequestVoteReply) bool {
	for {
		ok := rf.peers[peer].Call("Raft.RequestVote", args, reply)
		if ok {
			rf.receivedVoteReply <- *reply
			return ok
		}
	}
	//return ok
}

func (rf *Raft) sendAppendEntries(peer int, args *AppendEntriesArgs, reply *AppendEntriesReply) bool {
	for {
		ok := rf.peers[peer].Call("Raft.AppendEntries", args, reply)
		if ok {
			rf.receivedAppendReply <- *reply
			return ok
		}
	}
}
//
// Start
// =====
//
// The service using Raft (e.g. a k/v peer) wants to start
// agreement on the next command to be appended to Raft's log
//
// If this peer is not the leader, return false
//
// Otherwise start the agreement and return immediately
//
// There is no guarantee that this command will ever be committed to
// the Raft log, since the leader may fail or lose an election
//
// The first return value is the index that the command will appear at
// if it is ever committed
//
// The second return value is the current term
//
// The third return value is true if this peer believes it is
// the leader
//
func (rf *Raft) Start(command interface{}) (int, int, bool) {
	// index := -1
	// term := -1
	// isLeader := true

	if rf.isLeader == false {
		return 0, 0, false
	}
	// Your code here (2B)

	return 0, 0, rf.isLeader
}

//
// Kill
// ====
//
// The tester calls Kill() when a Raft instance will not
// be needed again
//
// You are not required to do anything
// in Kill(), but it might be convenient to (for example)
// turn off debug output from this instance
//
func (rf *Raft) Kill() {
	// Your code here, if desired
	//rf.killTimeout <- true
}

//
// Make
// ====
//
// The service or tester wants to create a Raft peer
//
// The port numbers of all the Raft peers (including this one)
// are in peers[]
//
// This peer's port is peers[me]
//
// All the peers' peers[] arrays have the same order
//
// applyCh
// =======
//
// applyCh is a channel on which the tester or service expects
// Raft to send ApplyMsg messages
//
// Make() must return quickly, so it should start Goroutines
// for any long-running work
//
func Make(peers []*rpc.ClientEnd, me int, applyCh chan ApplyMsg) *Raft {
	//fmt.Println("Make called for ", me)
	rf := &Raft{
	peers : peers,
	me : me,

	// Your initialization code here (2A, 2B)
	// Should be the same always. On all servers.
	currentTerm : 0,
	votedFor : -1,
	// Should this be a list? Cuz we clearly don't have a length for this.
	log : list.New(),	// Should I make another struct?
	// TODO: One of these starts with 1
	lastTerm : 0,
	lastIndex : 0,
	timeout : random(500, 1000),
  // Changes randomly
	commitIndex : 0,
	lastApplied : 0,
	voteCount : 0,
	// Leader state (reinitialised on election)

	// TODO: What should be the length here?
	isLeader : false,
	nextIndex : make([]int, len(peers)),
	matchIndex : make([]int, len(peers)),
	leaderElected : make(chan bool),
	receivedMsg : make(chan bool),
	receivedVoteReply : make(chan RequestVoteReply, len(peers)),
	receivedAppendReply : make(chan AppendEntriesReply, len(peers)),
	killTimeout : make(chan bool),
	}
	//fmt.Println("Make finished ", rf.timeout)
	go rf.timeout_routine()

	return rf
}

// Generate a random number for timeout
func random(min, max int) int {
	rand.Seed(time.Now().UTC().UnixNano())
	return rand.Intn(max - min) + min
}

// goroutine to kick-off election after timeout.
func (rf *Raft) timeout_routine() {
	//fmt.Println("Reached here")
	rf.mux.Lock()
	rf.isLeader = false
	rf.currentTerm = 0
	rf.mux.Unlock()
	//count := 0
	ticker := time.NewTicker(time.Duration(random(800, 1500)) * time.Millisecond)
	tickerHeartbeat := time.NewTicker(100 * time.Millisecond)
	for {
		select{
		case <- ticker.C:
			rf.mux.Lock()
			//fmt.Printf("Timed out term %d server %d\n", rf.currentTerm, rf.me)
			rf.mux.Unlock()
			rf.startNewElection()
			ticker.Stop()
			ticker = time.NewTicker(time.Duration(random(800, 1500)) * time.Millisecond)
		case <- rf.receivedMsg:
			// Reset timer
			//fmt.Println("Reseting timer ", rf.me)
			ticker.Stop()
			ticker = time.NewTicker(time.Duration(random(800, 1500)) * time.Millisecond)
		case <- rf.leaderElected:
			ticker.Stop()
			tickerHeartbeat = time.NewTicker(125 * time.Millisecond)
			// Reset timer
		case <- tickerHeartbeat.C:
			// WARN: Accessing variable rf.peers without mutex
			rf.mux.Lock()
			//fmt.Printf("Server %d is leader %v\n", rf.me, rf.isLeader)
			if rf.isLeader == false {
				tickerHeartbeat.Stop()
				rf.mux.Unlock()
				continue
			}
			ticker.Stop()
			numPeers := len(rf.peers)
			rf.mux.Unlock()
			for i := 0; i < numPeers; i++ {
				if i != rf.me {
					rf.mux.Lock()
					args := AppendEntriesArgs{Term: rf.currentTerm, LeaderId: rf.me,
						PrevLogIndex: rf.lastIndex, PrevLogTerm: rf.lastTerm, LeaderCommit: rf.commitIndex}
					reply := AppendEntriesReply{}
					rf.mux.Unlock()
					//fmt.Println("Sending heartbeat ", rf.me)
					go rf.sendAppendEntries(i, &args, &reply)
				}

				// Check if the replies are true and revert to follower if false
				// Also restart ticker if follower
			}
		case replied := <- rf.receivedVoteReply:
			rf.mux.Lock()
			if replied.Term == rf.currentTerm {
				if replied.VoteGranted {
					rf.voteCount++
				} else {
					if replied.Term > rf.currentTerm {
						rf.currentTerm = replied.Term
					}
				}
				if rf.voteCount > (len(rf.peers) / 2) {
					//fmt.Println("Yay ", rf.me)
					rf.isLeader = true
					rf.voteCount = 0
					ticker.Stop()
					tickerHeartbeat = time.NewTicker(125 * time.Millisecond)
				}
			}
			rf.mux.Unlock()
		case reply := <- rf.receivedAppendReply:
			rf.mux.Lock()
			if reply.Term == rf.currentTerm {
				if reply.Success == false {
					//fmt.Println("No longer leader : ", rf.me)
						rf.isLeader = false
						rf.currentTerm = reply.Term
						ticker = time.NewTicker(time.Duration(random(800, 1200)) * time.Millisecond)
						tickerHeartbeat.Stop()
				}
			}
			rf.mux.Unlock()
		case <- rf.killTimeout:
			ticker.Stop()
			tickerHeartbeat.Stop()
			return
		}
	}
}


func (rf *Raft) startNewElection() {
	rf.mux.Lock()
	//fmt.Println("Starting new election: Initial term ", rf.currentTerm)
	rf.currentTerm = rf.currentTerm + 1
	rf.votedFor = rf.me
	numPeers := len(rf.peers)

	rf.voteCount = 1
	//fmt.Printf("Starting new election %d with term %d \n", rf.me, rf.currentTerm)
	rf.mux.Unlock()

	for i := 0; i < numPeers; i++ {
		if i != rf.me {
			rf.mux.Lock()
			args := &RequestVoteArgs{rf.currentTerm, rf.me, rf.lastIndex, rf.lastTerm}
			reply := &RequestVoteReply{}
			rf.mux.Unlock()
			go rf.sendRequestVote(i, args, reply)
		}
	}
	return
}
